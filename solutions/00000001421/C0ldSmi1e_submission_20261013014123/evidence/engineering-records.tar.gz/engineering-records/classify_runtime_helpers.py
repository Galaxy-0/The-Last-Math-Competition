#!/usr/bin/env python3
"""Explicit classification of all frozen-1421 compiler runtime helpers."""
import collections
import hashlib
import json
from pathlib import Path
import re

if not __debug__:
    raise RuntimeError("Runtime classification requires assertions")

OUT = Path(__file__).resolve().parent
D = OUT.parents[2]
SOURCE = D / "1421/review-source/lean"
data = json.loads((OUT / "declaration-audit.json").read_text())
helpers = json.loads((OUT / "runtime-helper-inventory.json").read_text())
roots = {r["name"]: r for r in data["declarations"]}
graph = {r["name"]: r for r in data["dependency_graph"]}
safe = [r for r in roots.values() if not r["unsafe"]]
safe_closure = {name for root in safe for name in root["closure"]}
assert len(helpers) == 50 and len(safe) == 292
assert {r["name"] for r in helpers}.isdisjoint(safe_closure)
assert all(not graph[n]["unsafe"] and graph[n]["kind"] != "unavailable" for n in safe_closure)
assert {"lcProof", "_obj", "_neutral"}.isdisjoint(safe_closure)
assert all(set(r["axioms"]) <= {"propext", "Classical.choice", "Quot.sound"} for r in safe)

anchors = {
    "Conjecture1421.characterEquiv": ("Conjecture1421/Spectrum.lean", "characterEquiv", "character product equivalence"),
    "Conjecture1421.firstRestriction": ("Conjecture1421/Spectrum.lean", "firstRestriction", "first character restriction"),
    "Conjecture1421.secondRestriction": ("Conjecture1421/Spectrum.lean", "secondRestriction", "second character restriction"),
    "Conjecture1421.productChar": ("Conjecture1421/Spectrum.lean", "productChar", "product character construction"),
    "Conjecture1421.coordKernel": ("Conjecture1421/Powers.lean", "coordKernel", "coordinate kernel definition"),
    "Conjecture1421.size": ("Conjecture1421/Basic.lean", "size", "natural-to-real size coercion"),
    "Conjecture1421.support": ("Conjecture1421/Basic.lean", "support", "finite support filter and its specialized list/multiset implementation"),
}
rows = []
for helper in helpers:
    name = helper["name"]
    assert helper["unsafe"] is True and helper["trust_enforced"] is False
    parent = next((prefix for prefix in anchors if name.startswith(prefix + ".")), None)
    if parent is None:
        assert "._at.Conjecture1421.support._spec_" in name
        parent = "Conjecture1421.support"
    source_path, short_name, purpose = anchors[parent]
    text = (SOURCE / source_path).read_text()
    assert name not in text
    assert not roots[parent]["unsafe"] and roots[parent]["kind"] == "definition"
    line = next(i for i, line in enumerate(text.splitlines(), 1) if line.startswith("def " + short_name + " "))
    if helper["kind"] == "axiom":
        if re.search(r"\._elambda_[0-9]+$", name):
            category = "unsafe compiler placeholder for eager lambda lifting"
        else:
            assert re.search(r"\._at\.Conjecture1421\.support\._spec_[0-9]+$", name)
            category = "unsafe compiler placeholder for specialized support-filter implementation"
    else:
        assert helper["kind"] == "definition" and re.search(r"\._cstage[12]$", name)
        category = "unsafe compiler stage definition"
        if "._closed_" in name:
            category += " for lifted closed value"
        elif "._rarg" in name:
            category += " for erased-argument runtime function"
        elif "._elambda_" in name:
            category += " for lifted lambda"
        elif "._spec_" in name:
            category += " for specialized runtime function"
    assert not any(name in root["closure"] for root in safe)
    rows.append({"name": name, "kind": helper["kind"], "module": helper["module"], "classification": category, "source_parent": parent, "source_file": source_path, "source_line": line, "source_purpose": purpose, "present_in_authored_source": False, "appears_in_safe_root_closures": 0, "type": helper["type"], "runtime_only_axioms": helper["axioms"], "runtime_only_unsafe_dependencies": helper["unsafe_dependencies"]})

assert collections.Counter(r["kind"] for r in helpers) == {"definition": 42, "axiom": 8}
unavailable = sorted(name for name, row in graph.items() if row["kind"] == "unavailable")
assert set(unavailable).isdisjoint(safe_closure)
frozen = json.loads((D / "1421/frozen-review-manifest.json").read_text())
assert all(not set(roots[name]["closure"]) & {r["name"] for r in helpers} for name in frozen["capstones"])
runtime_source = D / "runtime/lean-4.19.0-darwin_aarch64/src/lean"
refs = ["Lean/Compiler/Old.lean", "Init/Prelude.lean", "Lean/Compiler/LCNF/ToLCNF.lean", "Lean/CoreM.lean"]
references = [{"path": str(runtime_source / p), "sha256": hashlib.sha256((runtime_source / p).read_bytes()).hexdigest()} for p in refs]
result = {"status": "PASS_EXPLICIT_RUNTIME_HELPER_CLASSIFICATION", "raw_summary_status_preserved": json.loads((OUT / "summary.json").read_text())["status"], "basis": "Fresh owned source compilation produced these declarations; complete authored source review found none of these names or unsafe/axiom declarations. Their module origins, names, types and bodies fit the supplied Lean compiler's generated stage/lambda/specialization machinery. Classification is relative to the supplied Lean runtime trust boundary; runtime source references explain conventions but do not authenticate or bootstrap binaries.", "mathematical_acceptance": "Only the 292 kernel-safe owned roots are mathematical evidence. All their complete closures exclude every unsafe helper, compiler placeholder axiom, unavailable compiler-only name, lcProof, _obj and _neutral. The fixed axiom policy remains propext, Classical.choice, Quot.sound. All five capstones have no helper exposure.", "helper_count": 50, "helper_kind_counts": dict(collections.Counter(r["kind"] for r in helpers)), "source_parent_counts": dict(collections.Counter(r["source_parent"] for r in rows)), "safe_root_count": len(safe), "safe_union_closure_count": len(safe_closure), "unavailable_runtime_only_names": unavailable, "compiler_runtime_finding_count": len(data["compiler_runtime_findings"]), "raw_inventory_sha256": hashlib.sha256((OUT / "runtime-helper-inventory.json").read_bytes()).hexdigest(), "runtime_source_references": references, "helpers": rows}
assert result["raw_summary_status_preserved"] == "PASS_PENDING_RUNTIME_HELPER_CLASSIFICATION"
(OUT / "runtime-helper-classification.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k not in ("helpers", "runtime_source_references")}, indent=2))
