#!/usr/bin/env python3
"""Reviewer checks for this frozen submission; never changes driver evidence."""
import collections
import hashlib
import json
from pathlib import Path
import re

if not __debug__:
    raise RuntimeError("Reviewer checks require assertions")

OUT = Path(__file__).resolve().parent
D = OUT.parents[2]
SUBMISSION = D / "1421/review-source/lean"
FROZEN = D / "1421/frozen-review-manifest.json"
PERMITTED = {"propext", "Classical.choice", "Quot.sound"}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name):
    return json.loads((OUT / name).read_text())


summary = read("summary.json")
assert sha(FROZEN) == "db3effdd39210ad094c0f16e0fba2f19819086aa9cee8a921208b3cf0eb055f0"
frozen = json.loads(FROZEN.read_text())
assert sha(FROZEN) == summary["frozen_manifest_sha256"]
assert sha(OUT / "selected-manifest.json") == sha(FROZEN)
assert {str(p.relative_to(SUBMISSION)): sha(p) for p in SUBMISSION.rglob("*") if p.is_file()} == frozen["files"]
assert all(not p.is_symlink() for p in SUBMISSION.rglob("*"))
sources = sorted(name for name in frozen["files"] if name.endswith(".lean"))
modules = [str(Path(name).with_suffix("")).replace("/", ".") for name in sources]
assert len(set(modules)) == len(modules) == 8
assert sum(len((SUBMISSION / name).read_text().splitlines()) for name in sources) == 1395
for name in sources:
    assert len(Path(name).name.split(".")) == 2
    for line in (SUBMISSION / name).read_text().splitlines():
        if re.match(r"^\s*import\s", line):
            assert re.fullmatch(r"\s*import\s+[A-Za-z_][A-Za-z_0-9.]*\s*", line)
assert summary["modules"] == modules
assert read("active-source-token-audit.json") == []

receipts = []
expected_rejections = []
for p in sorted((OUT / "receipts").glob("*.json")):
    r = json.loads(p.read_text())
    stdout, stderr = p.with_suffix(".stdout"), p.with_suffix(".stderr")
    assert sha(stdout) == r["stdout_sha256"] and sha(stderr) == r["stderr_sha256"]
    assert stderr.read_bytes() == b"", p
    assert r["argv"] == r["effective_argv"]
    assert all(value == frozen["files"][name] for name, value in r["active_source_hashes"].items() if name in frozen["files"])
    if r["expected_exit"] == "nonzero":
        assert r["exit_code"] != 0
        expected_rejections.append(p.stem)
    else:
        assert r["expected_exit"] == r["exit_code"] == 0
    receipts.append({"receipt": p.stem, "argv": r["argv"], "exit_code": r["exit_code"], "expected_exit": r["expected_exit"], "stdout_bytes": stdout.stat().st_size, "stderr_bytes": 0})
assert len(receipts) == 62
assert len(expected_rejections) == 6
assert "Lean (version 4.19.0," in (OUT / "receipts/0001.stdout").read_text()
assert "Lake version 5.0.0-6caaee8 (Lean version 4.19.0)" in (OUT / "receipts/0002.stdout").read_text()
build = receipts[38]
assert build["argv"][-4:] == [str(D / "runtime/lean-4.19.0-darwin_aarch64/bin/lake"), "--no-cache", "--wfail", "build"]
assert "Build completed successfully." in (OUT / "receipts/0039.stdout").read_text()
replays = receipts[39:47]
assert {r["argv"][-1] for r in replays} == set(sources)
assert all("-DwarningAsError=true" in r["argv"] for r in replays)
assert len(read("lake-build-outputs.json")) == 7
assert len(read("replay-build-outputs.json")) == 8
assert len(read("audited-build-outputs.json")) == 9

data = read("declaration-audit.json")
assert data["requested_modules"] == modules
assert data["strict_dependency_policy"] is True
assert data["kernel_roots_only"] is True
assert data["kernel_check_performed"] is False
assert set(data["permitted_axioms"]) == PERMITTED
assert data["failures"] == summary["audit_failures"] == []
roots = {r["name"]: r for r in data["declarations"]}
graph = {r["name"]: r for r in data["dependency_graph"]}
assert len(roots) == len(data["declarations"]) == data["local_declaration_count"] == summary["local_declaration_count"]
assert len(graph) == len(data["dependency_graph"]) == data["closure_declaration_count"] == summary["closure_declaration_count"]
shared_fields = ("name", "module", "kind", "unsafe", "dependencies", "type_dependencies", "body_dependencies", "recursor_dependencies", "inductive_dependencies")
for name, root in roots.items():
    assert all(root[field] == graph[name][field] for field in shared_fields), name
    assert root["trust_enforced"] is (not root["unsafe"])
    assert root["module"] in modules
    if not root["unsafe"]:
        assert set(root["axioms"]) <= PERMITTED
        assert root["unsafe_dependencies"] == []
        assert all(not graph[n]["unsafe"] and graph[n]["kind"] != "unavailable" for n in root["closure"])
        assert set(root["lean_collectAxioms"]) <= PERMITTED
assert len(set(data["imported_modules"])) == len(data["imported_modules"])
imports = read("import-identities.json")
assert {r["module"] for r in imports} == set(data["imported_modules"])
assert len(imports) == summary["import_identity_count"]
for row in imports:
    assert sha(Path(row["resolved_path"])) == row["olean_sha256"]
assert [r for r in roots.values() if r["unsafe"]] == read("runtime-helper-inventory.json")
assert summary["runtime_helper_count"] == len(read("runtime-helper-inventory.json"))
assert summary["capstones"] == frozen["capstones"]
capstone_rows = []
for name in frozen["capstones"]:
    root = roots[name]
    assert root["kind"] == "theorem" and not root["unsafe"] and root["trust_enforced"]
    assert set(root["axioms"]) == PERMITTED
    capstone_rows.append({key: root[key] for key in ("name", "type", "raw_type", "axioms", "unsafe_dependencies")})

packages = read("package-identities.json")
manifest = json.loads((SUBMISSION / "lake-manifest.json").read_text())
assert len(packages) == len(manifest["packages"]) == 9
assert sum(r["tracked_files"] for r in packages) == 7507
assert {r["package"]: r["revision"] for r in packages} == {r["name"]: r["rev"] for r in manifest["packages"]}
for row in packages:
    inventory = OUT / "stock" / (row["package"] + ".json")
    assert sha(inventory) == row["inventory_sha256"]
    assert len(json.loads(inventory.read_text())) == row["tracked_files"]
assert all(r["unchanged"] and r["before"] == r["after"] for r in read("stock-index-stability.json"))
for path, digest in read("runtime-identities.json").items():
    assert sha(Path(path)) == digest
for name, digest in summary["expected_pins"].items():
    assert sha(D / "1421/expected-pins" / name) == digest
assert len(read("runtime-identities.json")) == 8
controls = read("control-results.json")
assert [r["fixture"] for r in controls] == ["Good", "Axiom", "Transitive", "Sorry", "Native", "Unsafe"]
assert not controls[0]["failures"] and not controls[0]["expected_rejected"]
assert all(r["failures"] and r["expected_rejected"] for r in controls[1:])

author = json.loads((D / "1421/author/strict-replay.json").read_text())
assert author["files"] == frozen["files"]
assert len(author["results"]) == 8 and all(r["exit_code"] == 0 and not r["stderr"] for r in author["results"])
audit_author = next(r for r in author["results"] if r["module"] == "Conjecture1421/Audit.lean")
assert audit_author["stdout"].startswith((OUT / "receipts/0047.stdout").read_text())

result = {"status": "PASS_SUPPLEMENTARY_ENGINEERING_CHECKS", "scope": "Additional fixed-policy, receipt, source, import and root/graph consistency checks; no replacement for Lean replay or independent environment extraction.", "raw_summary_status_preserved": summary["status"], "receipt_count": len(receipts), "all_receipt_stderr_empty": True, "expected_nonzero_receipts": expected_rejections, "raw_commands": receipts, "capstone_types": capstone_rows, "local_declarations": len(roots), "safe_local_declarations": sum(not r["unsafe"] for r in roots.values()), "closure_declarations": len(graph), "import_counts_by_package": dict(collections.Counter(r["package"] for r in imports)), "pinned_packages": 9, "tracked_files": 7507, "runtime_identities": 8, "author_results_comparison": "Eight successful strict replays and exact capstone axiom output agree; author results consulted after independent successful build/replay and never used as proof input."}
(OUT / "supplementary-review.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k not in ("raw_commands", "capstone_types")}, indent=2))
