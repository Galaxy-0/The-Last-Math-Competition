import Conjecture1030

noncomputable section
open MeasureTheory
open scoped BigOperators
open Conjecture1030

-- Check the actual L² ambient spaces and actual normalized H² definition.
example : E = EuclideanSpace ℝ (Fin 3) := rfl
example : sigma =
    ((Measure.hausdorffMeasure (2 : ℝ) : Measure S2) Set.univ)⁻¹ •
      (Measure.hausdorffMeasure (2 : ℝ) : Measure S2) := rfl

-- State exactness independently with the measure expanded, and recover the
-- final lower bound. This must not require a moment, LP, or rigidity premise.
example (X : Finset S2) (hne : X.Nonempty)
    (hexact : ∀ p : MvPolynomial (Fin 3) ℝ, p.totalDegree ≤ 5 →
      (X.card : ℝ)⁻¹ * ∑ x ∈ X, MvPolynomial.eval (fun i => (x : E) i) p =
        ∫ x : S2, MvPolynomial.eval (fun i => (x : E) i) p
          ∂(((Measure.hausdorffMeasure (2 : ℝ) : Measure S2) Set.univ)⁻¹ •
            (Measure.hausdorffMeasure (2 : ℝ) : Measure S2))) :
    12 ≤ X.card :=
  spherical_five_design_card_ge_twelve X ⟨hne, hexact⟩

-- Empty sets cannot satisfy the exported predicate, despite cleared averages.
example : ¬ SphericalDesign 5 (∅ : Finset S2) := by
  simp [SphericalDesign]

-- Check existence and a literal least-attained-cardinality formulation.
example : IsLeast {n : ℕ | ∃ X : Finset S2, SphericalDesign 5 X ∧ X.card = n} 12 := by
  constructor
  · exact spherical_five_design_minimum_twelve.1
  · intro n hn
    obtain ⟨X, hX, hc⟩ := hn
    simpa only [hc] using spherical_five_design_card_ge_twelve X hX

-- Check that equality produces an actual ambient orthogonal congruence.
example (X : Finset S2) (hX : SphericalDesign 5 X) (hc : X.card = 12) :
    ∃ U : E ≃ₗᵢ[ℝ] E, X.image (sphereIso U) = ico :=
  spherical_five_design_twelve_rigidity X hX hc

-- Both parenthetical readings remain visible in the exported statements.
example (X : Finset S2) (hX : SphericalDesign 5 X) (hn : ¬ IsIcosahedral X) :
    13 ≤ X.card := nonicosahedral_spherical_five_design_card_ge_thirteen X hX hn

example : ¬ ∃ X : Finset S2, SphericalDesign 5 X ∧ ¬ IsIcosahedral X ∧ X.card = 12 :=
  no_twelve_point_nonicosahedral_spherical_five_design

#print axioms Conjecture1030.map_surface
#print axioms Conjecture1030.surface_mass_pos
#print axioms Conjecture1030.surface_mass_lt_top
#print axioms Conjecture1030.sigmaProbability
#print axioms Conjecture1030.sigma_orthogonallyInvariant
#print axioms Conjecture1030.sphereMonomial_integral
#print axioms Conjecture1030.designFor_of_monomial_exact
#print axioms Conjecture1030.ico_card
#print axioms Conjecture1030.ico_is_spherical_five_design
#print axioms Conjecture1030.card_ge_twelve_of_lp_sum
#print axioms Conjecture1030.lpValue_inner_eq_zero_of_twelve
#print axioms Conjecture1030.exists_antipode_of_squared_sum
#print axioms Conjecture1030.design_sum_lpValue
#print axioms Conjecture1030.spherical_five_design_card_ge_twelve
#print axioms Conjecture1030.spherical_five_design_twelve_rigidity
#print axioms Conjecture1030.spherical_five_design_card_twelve_iff
#print axioms Conjecture1030.spherical_five_design_minimum_twelve
#print axioms Conjecture1030.nonicosahedral_spherical_five_design_card_ge_thirteen
#print axioms Conjecture1030.no_twelve_point_nonicosahedral_spherical_five_design
