import Conjecture1030
import Lean
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let wanted := #["Conjecture1030.Definitions", "Conjecture1030.SurfaceMeasure", "Conjecture1030.SphereMoments", "Conjecture1030.LinearProgramming", "Conjecture1030.DesignExactness", "Conjecture1030.Icosahedron", "Conjecture1030.IcosahedronRigidity", "Conjecture1030.Theorem"]
  let mut count := 0
  for (n, ci) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? n then
      if wanted.contains env.header.moduleNames[idx]!.toString then
        count := count + 1
        if ci.isUnsafe then logInfo m!"RUNTIME {n}: {ci.type}"
  logInfo m!"Owned declaration count: {count}"
