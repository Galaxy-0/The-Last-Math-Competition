import Lean
open Lean
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
namespace Original
def expressionNames (e : Expr) (found : NameSet) : NameSet :=
  match e with
  | .const n _ => found.insert n
  | .app f a => expressionNames a (expressionNames f found)
  | .lam _ t b _ | .forallE _ t b _ => expressionNames b (expressionNames t found)
  | .letE _ t v b _ => expressionNames b (expressionNames v (expressionNames t found))
  | .mdata _ b => expressionNames b found
  | .proj n _ b => expressionNames b (found.insert n)
  | _ => found


end Original
namespace Candidate
def expressionNames (e : Expr) (found : NameSet) : NameSet := Id.run do
  -- Structural memoization preserves every child and name examined by the
  -- original traversal while visiting a shared expression only once.
  let mut visited : Std.HashSet ExprStructEq := {}
  let mut pending := [e]
  let mut found := found
  while !pending.isEmpty do
    let e := pending.head!
    pending := pending.tail!
    if !visited.contains ⟨e⟩ then
      visited := visited.insert ⟨e⟩
      match e with
      | .const n _ => found := found.insert n
      | .app f a => pending := f :: a :: pending
      | .lam _ t b _ | .forallE _ t b _ => pending := t :: b :: pending
      | .letE _ t v b _ => pending := t :: v :: b :: pending
      | .mdata _ b => pending := b :: pending
      | .proj n _ b =>
        found := found.insert n
        pending := b :: pending
      | _ => pure ()
  return found


end Candidate

def ordered (names : NameSet) : Array String :=
  names.toList.toArray.map Name.toString |>.qsort (· < ·)

def fixtureExpressions : Array Expr := Id.run do
  let atoms : Array Expr := #[.const `Alpha [], .const `Beta [.param `UniverseNotConstant],
    .sort (.param `SortNotConstant), .bvar 0, .fvar ⟨`FreeNotConstant⟩,
    .mvar ⟨`MetaNotConstant⟩, .lit (.natVal 23), .lit (.strVal "NotAConstant")]
  let mut fixtures := atoms
  for i in [:atoms.size] do
    let a := atoms[i]!
    let b := atoms[(i+1)%atoms.size]!
    let c := atoms[(i+2)%atoms.size]!
    fixtures := fixtures ++ #[.app a b, .lam `IgnoredBinder a b .implicit,
      .forallE `IgnoredBinder a b .instImplicit, .letE `IgnoredBinder a b c false,
      .mdata {} a, .proj `ProjectionOnly 0 a,
      .app (.proj `OtherProjection 2 a) (.proj `ProjectionOnly 0 b)]
  let base := fixtures
  for e in base do
    let mut shared := e
    for _ in [:8] do
      shared := .app shared shared
    fixtures := fixtures.push shared
  return fixtures

#eval do
  let fixtures := fixtureExpressions
  for e in fixtures do
    let seed : NameSet := ({} : NameSet).insert `SeedMustStay
    let expected := ordered (Original.expressionNames e seed)
    let actual := ordered (Candidate.expressionNames e seed)
    unless expected == actual do
      throw <| IO.userError s!"Expression dependency mismatch: {expected} != {actual}"
  IO.println s!"PASS: {fixtures.size} exact expression comparisons including all constructors and shared DAGs"

#eval do
  let mut huge : Expr := .proj `LargeDagProjection 0 (.const `LargeDagLeaf [])
  for _ in [:80] do
    huge := .app huge huge
  let actual := ordered (Candidate.expressionNames huge {})
  unless actual == #["LargeDagLeaf", "LargeDagProjection"] do
    throw <| IO.userError s!"Large shared DAG names changed: {actual}"
  IO.println "PASS: depth-80 shared expression DAG (over 2^80 tree leaves)"
