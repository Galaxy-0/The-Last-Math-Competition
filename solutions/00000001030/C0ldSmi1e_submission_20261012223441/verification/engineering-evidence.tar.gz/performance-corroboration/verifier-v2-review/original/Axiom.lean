import Lean
axiom unrelatedAssumption : False
theorem harmless : True := True.intro
