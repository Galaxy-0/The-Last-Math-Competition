import Lean
axiom opaqueAssumption : False
opaque hidden : False := opaqueAssumption
theorem transitivelyBad : False := hidden
