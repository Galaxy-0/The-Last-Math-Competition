#!/usr/bin/env python3
"""Independent, local-only audit implementation differential fixtures."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

HERE = Path(__file__).resolve().parent
D = HERE.parent.parent.parent
LEAN = D / "runtime/lean-4.19.0-darwin_aarch64/bin/lean"
TEMPLATES = {
    "original": D / "verification-tools/templates/ClosureAudit.lean.txt",
    "v2": D / "1030/independent-review/verifier-v2/templates/ClosureAudit.lean.txt",
}
TOOLS = r'''import Lean
open Lean Elab Command
elab "make_shared_fixture" : command => do
  liftCoreM do
    let mut value := mkConst ``Nat.zero
    for _ in [:12] do
      value := mkApp2 (mkConst ``Nat.add) value value
    addDecl <| .defnDecl {
      name := `AuditFixture.sharedDag
      levelParams := []
      type := mkConst ``Nat
      value := value
      hints := .opaque
      safety := .safe
    }
    addDecl <| .defnDecl {
      name := `AuditFixture.rawProjection
      levelParams := []
      type := .forallE `b (mkConst `AuditFixture.Box) (mkConst ``Nat) .default
      value := .lam `b (mkConst `AuditFixture.Box) (.proj `AuditFixture.Box 0 (.bvar 0)) .default
      hints := .opaque
      safety := .safe
    }
'''
FIXTURES = {
    "Good": r'''import FixtureTools
namespace AuditFixture
structure Box where
  value : Nat
def project (box : Box) : Nat := box.value
mutual
inductive Branch where
  | leaf : Nat → Branch
  | fork : Branches → Branch
inductive Branches where
  | nil : Branches
  | cons : Branch → Branches → Branches
end
def branchSize : Branch → Nat
  | .leaf n => n
  | .fork _ => 1
opaque hiddenIdentity : Nat → Nat := fun n => n
theorem useHidden (n : Nat) : hiddenIdentity n = hiddenIdentity n := rfl
end AuditFixture
make_shared_fixture
''',
    "Axiom": "import Lean\naxiom unrelatedAssumption : False\ntheorem harmless : True := True.intro\n",
    "Transitive": "import Lean\naxiom opaqueAssumption : False\nopaque hidden : False := opaqueAssumption\ntheorem transitivelyBad : False := hidden\n",
    "Sorry": "import Lean\ntheorem unfinished : False := by sorry\n",
    "Native": "import Lean\ntheorem nativeProof : (17 : Nat) + 5 = 22 := by native_decide\n",
    "Unsafe": "import Lean\nunsafe def runtimeOnly (n : Nat) : Nat := n\n",
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(project, env, args, expected=0):
    started = time.monotonic()
    result = subprocess.run([str(LEAN), *map(str, args)], cwd=project, env=env, capture_output=True, timeout=180)
    logs = project / "logs"
    logs.mkdir(exist_ok=True)
    seq = len(list(logs.glob("*.json")))
    prefix = logs / f"{seq:03}"
    prefix.with_suffix(".stdout").write_bytes(result.stdout)
    prefix.with_suffix(".stderr").write_bytes(result.stderr)
    prefix.with_suffix(".json").write_text(json.dumps({"argv": args, "exit_code": result.returncode, "expected": expected,
        "seconds": time.monotonic() - started}, indent=2, default=str) + "\n")
    assert (result.returncode == 0) if expected == 0 else (result.returncode != 0), result.stdout.decode() + result.stderr.decode()

def execute(label, template):
    project = HERE / label
    project.mkdir(exist_ok=False)
    lib = project / "lib"
    (lib / "Verification").mkdir(parents=True)
    (project / "Verification").mkdir()
    env = os.environ.copy()
    for key in ("LEAN_PATH", "LEAN_SRC_PATH", "LEAN_SYSROOT", "LAKE_HOME"):
        env.pop(key, None)
    env["LEAN_PATH"] = str(lib)
    shutil.copy2(template, project / "Verification/ClosureAudit.lean")
    run(project, env, ["-DwarningAsError=true", "-o", lib / "Verification/ClosureAudit.olean", "Verification/ClosureAudit.lean"])
    (project / "FixtureTools.lean").write_text(TOOLS)
    run(project, env, ["-DwarningAsError=true", "-o", lib / "FixtureTools.olean", "FixtureTools.lean"])
    result = {}
    for fixture, source in FIXTURES.items():
        (project / (fixture + ".lean")).write_text(source)
        flags = [] if fixture == "Sorry" else ["-DwarningAsError=true"]
        run(project, env, [*flags, "-o", lib / (fixture + ".olean"), fixture + ".lean"])
        for command in ("inspect_modules", "audit_modules", "audit_kernel_modules"):
            filename = fixture + "-" + command
            (project / (filename + ".lean")).write_text(
                f'import {fixture}\nimport Verification.ClosureAudit\n#{command} [{fixture}] "{filename}.json"\n')
            expected = 0 if command == "inspect_modules" or (command == "audit_kernel_modules" and fixture in {"Good", "Unsafe"}) else 1
            run(project, env, ["-DwarningAsError=true", filename + ".lean"], expected)
            result[filename] = json.loads((project / (filename + ".json")).read_text())
        print(label, fixture, "completed", flush=True)
    return result

def main():
    original = execute("original", TEMPLATES["original"])
    candidate = execute("v2", TEMPLATES["v2"])
    assert original.keys() == candidate.keys()
    rows = []
    for fixture in original:
        assert original[fixture] == candidate[fixture], f"Audit changed: {fixture}"
        rows.append({"fixture": fixture, "identical": True,
            "declarations": original[fixture]["local_declaration_count"],
            "closure_declarations": original[fixture]["closure_declaration_count"],
            "failures": len(original[fixture]["failures"])})
    good = candidate["Good-audit_kernel_modules"]
    declarations = {row["name"]: row for row in good["declarations"]}
    assert "AuditFixture.Box" in declarations["AuditFixture.rawProjection"]["body_dependencies"]
    assert declarations["AuditFixture.sharedDag"]["body_dependencies"] == ["Nat.add", "Nat.zero"]
    for name, row in declarations.items():
        if row["kind"] == "recursor":
            assert row["recursor_dependencies"], name
            assert row["inductive_dependencies"], name
    assert "opaqueAssumption" in {row["name"]:row for row in candidate["Transitive-inspect_modules"]["declarations"]}["transitivelyBad"]["axioms"]
    receipt = {"status": "PASS", "comparisons": rows,
        "templates": {name: {"path": str(path), "sha256": digest(path)} for name, path in TEMPLATES.items()}}
    (HERE / "differential-results.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))

if __name__ == "__main__":
    main()
