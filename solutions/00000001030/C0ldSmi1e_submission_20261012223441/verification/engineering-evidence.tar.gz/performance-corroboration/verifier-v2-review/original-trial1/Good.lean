import FixtureTools
namespace AuditFixture
structure Box where
  value : Nat
def project (box : Box) : Nat := box.value
mutual
inductive Branch where
  | leaf : Nat → Branch
  | fork : Branches → Branch
inductive Branches where
  | nil : Branches
  | cons : Branch → Branches → Branches
end
def branchSize : Branch → Nat
  | .leaf n => n
  | .fork _ => 1
opaque hiddenIdentity : Nat → Nat := fun n => n
theorem useHidden (n : Nat) : hiddenIdentity n = hiddenIdentity n := rfl
end AuditFixture
make_shared_fixture
