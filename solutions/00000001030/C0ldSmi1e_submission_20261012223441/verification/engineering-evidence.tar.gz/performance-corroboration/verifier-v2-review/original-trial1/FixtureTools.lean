import Lean
open Lean Elab Command
elab "make_shared_fixture" : command => do
  liftCoreM do
    let mut value := mkConst ``Nat.zero
    for _ in [:12] do
      value := mkApp2 (mkConst ``Nat.add) value value
    addDecl <| .defnDecl {
      name := `AuditFixture.sharedDag
      levelParams := []
      type := mkConst ``Nat
      value := value
      hints := .opaque
      safety := .safe
    }
    addDecl <| .defnDecl {
      name := `AuditFixture.rawProjection
      levelParams := []
      type := .forallE `b (mkConst `AuditFixture.Box) (mkConst ``Nat) .default
      value := .lam `b (mkConst `AuditFixture.Box) (.proj `AuditFixture.Box 0 (.bvar 0)) .default
      hints := .opaque
      safety := .safe
    }
